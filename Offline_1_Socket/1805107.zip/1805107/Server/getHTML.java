package Server;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Base64;
import java.util.Date;

public class getHTML {
    public static String getContent(String directoryPath) throws IOException
    {
        StringBuilder sb = new StringBuilder();
        File file;
        if((file = new File(System.getProperty("user.dir")+directoryPath)).isDirectory())
        {
            getHTML.getHTMLContent(sb,directoryPath);
            System.out.println("HTML DOC");
        }
        else if(getExtension(directoryPath).equals("png") || getExtension(directoryPath).equals("jpg"))
        {
            System.out.println("JPG FOUND");
            getImageContents(sb,directoryPath);
        }
        else if(getContentType(directoryPath).contains("text"))
        {
            getTextContents(sb,directoryPath);
            System.out.println("TEXT DOC");
        }

        return sb.toString();
    }

    public static String getHTMLContent(StringBuilder sb, String directoryPath) throws IOException {
        File file = new File("index.html");
        FileInputStream fis = new FileInputStream(file);
        BufferedReader br = new BufferedReader(new InputStreamReader(fis, "UTF-8"));
        String line;
        while(( line = br.readLine()) != null ) {
            if(line.trim().equals("{links}")){
                addContentToHTML(sb,directoryPath);
                continue;
            }
            sb.append( line );
            sb.append( '\n' );
        }

        String content = sb.toString();
        return content;
    }

    public static String getContentType(String directoryPath) throws IOException {
        if( new File(System.getProperty("user.dir")+directoryPath).isDirectory() )
        {
            return "text/html";
        }
        //TODO:forced image as text/html.
        else if(Files.probeContentType(Paths.get(System.getProperty("user.dir")+directoryPath)).equals("image/jpeg"))
        {
            return "text/html";
        }
        return Files.probeContentType(Paths.get(System.getProperty("user.dir")+directoryPath));
    }

    public static boolean shouldForceDownload(String directoryPath)
    {
        String fileExtension = getExtension(directoryPath);
        if(fileExtension.equals("") || fileExtension.equals("png") || fileExtension.equals("jpg") || fileExtension.equals("txt")) return false;
        return true;
    }

    public static String getExtension(String directoryPath)
    {
        File file = new File(System.getProperty("user.dir")+directoryPath);
        String fileName = file.getName();
        int dotIndex = fileName.lastIndexOf('.');
        String fileExtension = (dotIndex == -1) ? "" : fileName.substring(dotIndex + 1);
        System.out.println("Extension "+fileExtension);
        return fileExtension;
    }


    public static void addContentToHTML(StringBuilder sb, String directoryPath)
    {
        try{
            String fileExtension = getExtension(directoryPath);
            addDirectoryToHTML(sb,directoryPath);


        }
        catch (Exception e)
        {
            System.out.println("EXCEPTION AT "+directoryPath);
        }
    }

    private static void getTextContents(StringBuilder sb, String directoryPath) {
        try {
            BufferedReader br = new BufferedReader(new FileReader(System.getProperty("user.dir")+directoryPath));
            String line;
            while((line = br.readLine()) != null)
            {
                sb.append(line);
            }
            br.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void getImageContents(StringBuilder sb, String directoryPath) {
        Path path = Paths.get(System.getProperty("user.dir")+directoryPath);
        try{
            File indexfile = new File("index.html");
            FileInputStream fis = new FileInputStream(indexfile);
            BufferedReader br = new BufferedReader(new InputStreamReader(fis, "UTF-8"));
            String line;
            while(( line = br.readLine()) != null ) {
                if (line.trim().equals("{links}")) {
                    System.out.println("HERE");

                    byte[] bytes= Files.readAllBytes(path);
                    String base64Bytes= Base64.getEncoder().encodeToString(bytes);
                    sb.append("<img src=\"data:image/extension;base64,"+base64Bytes+"\">");
                    continue;
                }
                sb.append(line);
                sb.append('\n');
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }



    public static boolean addDirectoryToHTML(StringBuilder sb, String directoryPath)
    {
        try{

            File directory = new File(System.getProperty("user.dir")+directoryPath);
            File filesList[] = directory.listFiles();
            if(directoryPath.equals("/"))
            {
                sb.append("<b> <i> <li> <a href=\"root/\">root</li> </b> </i>");
                return true;
            }
            for(File file : directory.listFiles())
            {
                if(file.isDirectory()) sb.append("<b> <i> <li> <a href=\"" + directoryPath + file.getName() + "/\">" + file.getName() + "</li> </b> </i>");
                else sb.append("<li> <a href=\"" + directoryPath + file.getName() + "/\">" + file.getName() + "</li>");
            }
            return true;
        }
        catch (Exception e)
        {
            System.out.println("EXCEPTION AT "+directoryPath);
            return false;
        }

    }
    
}
