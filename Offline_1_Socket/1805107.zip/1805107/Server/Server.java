package Server;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
    public static void main(String[] args) throws IOException,ClassNotFoundException {
        ServerSocket serverSocket = new ServerSocket(5107);
        File logFile = new File("log.txt");
        BufferedWriter outLog = new BufferedWriter(new FileWriter(logFile));
        while(true)
        {
            Socket incomingSocket = serverSocket.accept();

            Thread serverThread = new ServerThread(outLog,incomingSocket);
            serverThread.start();
        }
    }
}
