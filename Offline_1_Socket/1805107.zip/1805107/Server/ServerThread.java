package Server;

import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import static Server.FileHandler.sendFile;


// TODO: setup of logfile properly, sending proper content type

public class ServerThread extends Thread{
    Socket socket;
    BufferedWriter outLog;
    public ServerThread(BufferedWriter outLog, Socket socket){
        this.socket=socket;
        this.outLog=outLog;
    }
    public void run()
    {
        try{
            DataInputStream in = new DataInputStream(socket.getInputStream());
            BufferedReader inBuff = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            DataOutputStream pr = new DataOutputStream(socket.getOutputStream());
            while(true)
            {
                String input = inBuff.readLine();
                if(input == null) continue;
                if(input.startsWith("GET"))
                {
                    System.out.println("RECEIVED GET REQUEST");
                    String address = input.split(" ")[1];

                    if( address.equals("/favicon.ico") ) continue;

                    outLog.append("Received Request: "+input+"\n");
                    outLog.append("SENT RESPONSE: \n");
                    System.out.println(address);

                    if(! new File(System.getProperty("user.dir")+address).exists()){
                        pr.write("HTTP/1.1 404 NOT FOUND\r\n".getBytes(StandardCharsets.UTF_8));
                        outLog.append("HTTP/1.1 404 NOT FOUND\n");
                        pr.write("Server: Java HTTP Server: 1.0\r\n".getBytes(StandardCharsets.UTF_8));
                        outLog.append("Server: Java HTTP Server: 1.0\n");
                        pr.write(("Date: " + new Date() + "\r\n").getBytes(StandardCharsets.UTF_8));
                        outLog.append("Date: " + new Date() + "\n");
                        pr.write(("Content-Length: " + 0 + "\r\n").getBytes(StandardCharsets.UTF_8));
                        outLog.append("Content-Length: " + 0 + "\n");
                        pr.write("\r\n".getBytes(StandardCharsets.UTF_8));
                        pr.flush();
                        outLog.flush();
                    }
                    else
                    {
                        String content = getHTML.getContent(address);

                        pr.write("HTTP/1.1 200 OK\r\n".getBytes(StandardCharsets.UTF_8));
                        outLog.append("HTTP/1.1 200 OK\n");

                        if(getHTML.shouldForceDownload(address)) {
                            File file = new File(System.getProperty("user.dir")+address);
                            pr.write(("Content-Disposition: attachment; filename=\"" + file.getName() + "\"\r\n").getBytes(StandardCharsets.UTF_8));
                            outLog.append("Content-Disposition: attachment; filename=\"" + file.getName() + "\"\n");
                            pr.write("Content-Type: application/force-download\r\n".getBytes(StandardCharsets.UTF_8));
                            outLog.append("Content-Type: application/force-download\n");
                            pr.write("Server: Java HTTP Server: 1.0\r\n".getBytes(StandardCharsets.UTF_8));
                            outLog.append("Server: Java HTTP Server: 1.0\n");
                            pr.write(("Date: " + new Date() + "\r\n").getBytes(StandardCharsets.UTF_8));
                            outLog.append("Date: " + new Date() + "\n");
                            pr.write(("Content-Length: " + file.length() + "\r\n").getBytes(StandardCharsets.UTF_8));
                            outLog.append("Content-Length: " + file.length() + "\n");
                            pr.write("\r\n".getBytes(StandardCharsets.UTF_8));
                            sendFile(pr,file);
                            pr.write("\r\n".getBytes(StandardCharsets.UTF_8));
                        }
                        else{
                            pr.write(("Content-Type: " + getHTML.getContentType(address) + "\r\n").getBytes(StandardCharsets.UTF_8));
                            outLog.append("Content-Type: " + getHTML.getContentType(address) + "\n");
                            pr.write("Server: Java HTTP Server: 1.0\r\n".getBytes(StandardCharsets.UTF_8));
                            outLog.append("Server: Java HTTP Server: 1.0\n");
                            pr.write(("Content-Length: " + content.length() + "\r\n").getBytes(StandardCharsets.UTF_8));
                            outLog.append("Content-Length: " + content.length() + "\n");
                            pr.write("\r\n".getBytes(StandardCharsets.UTF_8));
                            pr.write(content.getBytes(StandardCharsets.UTF_8));
                            pr.write("\r\n".getBytes(StandardCharsets.UTF_8));
                        }
                        pr.flush();
                        outLog.flush();
                    }
                }
                else if(input.startsWith("UPLOAD"))
                {
                    uploadFile(in, input);
                    break;
                }
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    private void uploadFile(DataInputStream in, String input)
    {

        try {
            outLog.append("RECEIVED REQUEST: "+ input+"\n");
            DataOutputStream out = new DataOutputStream(socket.getOutputStream());
            String filename = input.split(" ")[1];

            // first inputStream is emptied. Ready message then sent. Filename received. Filename confirmation is then sent(format check)
            // then file is received
            while(in.available()>0) in.read();
            if( ! filename.endsWith(".png") && !filename.endsWith(".jpg") && !filename.endsWith("mp4") && !filename.endsWith(".txt") )
            {
                out.writeUTF("FORMAT-ERROR");
                outLog.append("SENT RESPONSE: FORMAT-ERROR\n");
                out.flush();
                outLog.flush();
                return;
            }
            else {
                out.writeUTF("READY");
                outLog.append("SENT RESPONSE: READY\n");
            }
            out.flush();

            String fileOkConfirmation = in.readUTF();
            outLog.append("RECEIVED FILE CONFIRMATON: "+fileOkConfirmation+"\n");
            outLog.flush();
            if(fileOkConfirmation.equals("OK"))
            {
                receiveFile(in,out,filename);
            }
            else if(fileOkConfirmation.equals("FILE-NOT-FOUND"))
            {
                System.out.println("FILE NOT FOUND ON CLIENT SIDE. Given Filename: "+filename);
                outLog.append("FILE NOT FOUND ON CLIENT SIDE. Given Filename: "+filename+"\n");
                in.close();
                socket.close();
            }


        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    private void receiveFile(DataInputStream inData,DataOutputStream out,String filename) {
        try {


            FileOutputStream outFile = new FileOutputStream("root/uploadedFiles/"+filename);

            long totalSize = inData.readLong();
            System.out.println("totalSize is: "+totalSize);
            byte[] buffer = new byte[4*1024];
            int bytesRead;
            int chunks = 0;

            while(totalSize>0 && (bytesRead=inData.read(buffer)) != -1){
                chunks++;
                outFile.write(buffer,0,bytesRead);
                outFile.flush();
                totalSize -= bytesRead;
            }
            System.out.println("FILE RECEIVED. TOTAL CHUNKS: " + chunks);
            outLog.append("FILE RECEIVED. TOTAL CHUNKS: " + chunks+"\n");
            outFile.close();
            socket.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
