package Server;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.file.Path;
import java.util.List;

public class FileHandler {
    public static boolean sendFile(DataOutputStream out, File file) throws IOException {
        FileInputStream inFile = new FileInputStream(file);

        byte[] buffer = new byte[4*1024];
        int bytesRead;
        while( ( bytesRead = inFile.read(buffer)) != -1 )
        {
            out.write(buffer,0,bytesRead);
            out.flush();
        }
        return true;
    }

}
