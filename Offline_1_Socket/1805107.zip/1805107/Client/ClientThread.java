package Client;

import javax.xml.crypto.Data;
import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;

public class ClientThread extends Thread {
    String filename;

    public ClientThread(String filename) { this.filename = filename; }

    public void run()
    {
        try{
            File file;
            if(! (file =new File("clientFolder/"+filename)).exists() )
            {
                sendErrorClient();
            }
            else{
                sendFileClient(file);
            }
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }

    private void sendFileClient(File file)
    {
        Socket socket = null;
        try{
            socket = new Socket("localhost",5107);
            DataOutputStream out = new DataOutputStream(socket.getOutputStream());
            BufferedWriter outBuff = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
            FileInputStream inFile = new FileInputStream(file);
            //SEND OK is the message to let server know it is a file upload request
            outBuff.write("UPLOAD "+filename+"\r\n");
            outBuff.flush();

            DataInputStream inData = new DataInputStream(socket.getInputStream());
            String status = inData.readUTF();
            if(status.equals("FORMAT-ERROR"))
            {
                System.out.println("FILE FORMAT INVALID");
                out.close();
                inFile.close();
                socket.close();
                return;
            }

            out.writeUTF("OK");

            out.writeLong(file.length());
            byte[] buffer = new byte[4*1024];
            int bytesRead;
            int chunks = 0;
            while((bytesRead=inFile.read(buffer)) != -1){
//                System.out.println("SENDING FILE CHUNK");
                chunks++;
                out.write(buffer,0,bytesRead);
                out.flush();
            }
            System.out.println("FILE SEMT. TOTAL CHUNKS: " + chunks);
            out.close();
            inFile.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }


    //in case of failure SEND FAILED MESSAGE SENT to the server;
    //second is sent the filename. Server spec needs to show error message
    private void sendErrorClient()
    {
        Socket socket = null;
        try {
            socket = new Socket("localhost",5107);
            DataOutputStream out = new DataOutputStream(socket.getOutputStream());
            BufferedWriter outBuff = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));

            outBuff.write("UPLOAD "+filename+"\r\n");
            outBuff.flush();

            DataInputStream inData = new DataInputStream(socket.getInputStream());
            String status = inData.readUTF();

            if(status.equals("FORMAT-ERROR"))
            {
                System.out.println("FILE FORMAT INVALID");
                out.close();
                socket.close();
                return;
            }

            out.writeUTF("FILE-NOT-FOUND");
            System.out.println("FILE NOT IN FOLDER. NOTIFIED SERVER");

            out.flush();
            out.close();
            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}
