package Client;

import java.util.Scanner;

public class Client {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        while(true)
        {
            System.out.println("1.UPLOAD\t2.EXIT");
            String s=scanner.nextLine();
            if(s.equals("1"))
            {
                System.out.println("GIVE FILE NAME(including format): ");
                String filename=scanner.nextLine();
                ClientThread clientThread = new ClientThread(filename);
                clientThread.start();
            }
            else if(s.equals("2")) break;
            else {
                System.out.println("INVALID NUMBER. ONLY TYPE 1 or 2");
            }

        }
    }
}
